#include <LPC21xx.h>
#include "can.h"
#include "Adc.h"
#include "lcd.h"
#include "types.h"
#include "delay.h"
#include "defines.h"

#define LCD_DATA 0
#define LCD_RS 14
#define LCD_EN 15

/*
#define minVAL 729 // At 10cm
#define maxVAL 126 // At 80cm

long map(long val, long in_min, long in_max, long out_min, long out_max){
  return (val - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;
}*/

int main()
{
	u32 dist=0, val=0;
	f32 volt=0;
	struct CAN_Frame txFrame;
	
	txFrame.ID=2;   
	txFrame.BFV.RTR=0;
	txFrame.BFV.DLC=4;
	
	Init_ADC();
    Init_CAN1();
	InitLCD(LCD_DATA, LCD_RS, LCD_EN);

	while(1)
	{
		/*val = Read_ADC(CH1); // Get analog value from ADC
		dist = map(val, 1023, 0, 10, 80);*/
		
		val = Read_ADC(CH0); // P0.28
		volt = (val*3.3)/5.0;
		dist=((6787/(volt-3))-4);
		
        cmdLCD(CLEAR_LCD);
		cmdLCD(GOTO_LINE1_POS0);
		strLCD("Dist : ");
		u32LCD(dist);
        strLCD(" cm");
		
		if(dist<30)
		{
			cmdLCD(GOTO_LINE2_POS0);
			strLCD("ALERT!");
		}
		// Transmit Data
		txFrame.Data1=dist;
		CAN1_Tx(txFrame);
		
		delay_ms(500);
	}
}
