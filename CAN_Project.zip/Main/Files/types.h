typedef int s32;
typedef unsigned int u32;
typedef const int c32;
typedef const unsigned int cu32;
typedef unsigned short int  u16;
typedef signed short   int  s16;

typedef char s8;
typedef unsigned char u8;
typedef const char cs8;
typedef const unsigned char cu8;

typedef float f32;
typedef double d64;

typedef long int l32;
typedef unsigned long int ul32;

typedef long long int ll64;
typedef unsigned long long int ull64;

typedef long double ld128;

