#include "types.h"

//defines for ADCR
#define CH0                0x01
#define CH1                0x02
#define CH2                0x04
#define CH3                0x08

void Init_ADC(void);
u16 Read_ADC(u8 chNo);
