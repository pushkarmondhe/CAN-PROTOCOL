#include <LPC21xx.h>
#include "types.h"
#include "defines.h"
#include "delay.h"
#include "Adc.h"

#define CHANNEL_SEL        CH0|CH1
#define FOSC               12000000
#define CCLK               (5 * FOSC)
#define PCLK               CCLK/4
#define ADCLK              3750000
#define CLKDIV             (((PCLK/ADCLK)-1)<<8)

#define PDN_BIT            (1<<21) 
#define ADC_START_BIT      24 

//defines for ADDR 
#define DONE_BIT           31


void Init_ADC(void)
{
  ADCR=PDN_BIT|CLKDIV|CHANNEL_SEL;	
}

u16 Read_ADC(u8 chNo)
{
  u16 adcVal=0;
	//f32 eAR;
	
	WRITEBYTE(ADCR,0,chNo);
	SETBIT(ADCR,ADC_START_BIT);
	delay_us(3);
	
	while(!READBIT(ADDR,DONE_BIT));
	CLRBIT(ADCR,ADC_START_BIT);
	adcVal=(ADDR>>6)&0x3FF; // Get valuesfrom 0 - 1023
	// eAR=((adcVal*3.3)/1023); // Convert into Voltage
	return adcVal;
}
