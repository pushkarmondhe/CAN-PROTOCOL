#include <LPC21xx.h>
#include "can.h"
#include "Adc.h"
#include "lcd.h"
#include "types.h"
#include "delay.h"
#include "defines.h"

#define LED_AL 16
#define LCD_DATA 0
#define LCD_RS 14
#define LCD_EN 15

int main()
{
	u32 temp=0, val=0, per=0;
    struct CAN_Frame Frame;
	  
	Frame.BFV.RTR=0;
	Frame.BFV.DLC=4;
	
	Init_ADC();
    Init_CAN1();
	InitLCD(LCD_DATA, LCD_RS, LCD_EN);
	
	SETBIT(IODIR0, LED_AL);
	SSETBIT(IOSET0,LED_AL);

	while(1)
	{
		
		// Temperature ///////////////////////////////////////////////////////
		val=Read_ADC(CH0); // Pin no P0.27
		temp = (((f32)val*3.3)/1023) * 100;
		
		cmdLCD(CLEAR_LCD);
		cmdLCD(GOTO_LINE1_POS0); 
		strLCD("TEMP : ");
		u32LCD(temp);
        strLCD(" C");

		if(temp>55)
		{
			SCLRBIT(IOCLR0,LED_AL);
		}
		else
		{
			SSETBIT(IOSET0,LED_AL);
		}
		//delay_ms(1000);
		
		
		// Potentiometer /////////////////////////////////////////////////////
		val=Read_ADC(CH2); // Pin no P0.29
		per = (val*100)/1023;
		
		/*cmdLCD(GOTO_LINE1_POS0+8); 
		strLCD("Win: ");
		u32LCD(per);
        strLCD("%");*/
		
		// Transmit Frame to node 1
		Frame.ID=1;
		Frame.Data1=per;
		CAN1_Tx(Frame); 
		//delay_ms(1000);
		
		
		// Distance /////////////////////////////////////////////////////
		CAN1_Rx(&Frame); // Wait for Frame receive from Node 2
		if(Frame.ID==2)
		{
            //cmdLCD(CLEAR_LCD);
			cmdLCD(GOTO_LINE2_POS0);
			strLCD("Dist: ");
			u32LCD(Frame.Data1);
			
			if(Frame.Data1<30)
			{
				cmdLCD(GOTO_LINE2_POS0+9);
				strLCD("ALERT!");
			}
		}
        delay_ms(1000);	
	}
}
