#include <LPC21xx.h>
#include "types.h"
#include "defines.h"
#include "can.h"

#define CAN_RX 25

//TD1 CAN1_TX pin no alternate function,default
#define TD1_PIN       

#define PCLK          60000000  //Hz
#define BIT_RATE      125000    //Hz
#define QUANTA        16
#define BRP           (PCLK/(BIT_RATE*QUANTA))
#define SAMPLE_POINT  (0.7 * QUANTA)
#define TSEG1        	((u32)SAMPLE_POINT-1)
#define TSEG2        	(QUANTA-(1+TSEG1))	
#define SJW           ((TSEG2 < 5)?4:(TSEG2-1))

//cfg values for C1BTR sfr
#define TSEG1_LVAL  		(TSEG1-1)
#define TSEG2_LVAL  		(TSEG2-1)
#define BRP_LVAL    		(BRP-1)
#define SJW_LVAL    		(SJW-1)
#define SAM         0 //0 or 1 ,sample bus 1 or 3 time(s)
#define BTR_LVAL    (SAM<<23|(TSEG2_LVAL<<20)|(TSEG1_LVAL<<16)|(SJW_LVAL<<14)|BRP_LVAL)

//C1CMR sfr bit defines
#define TR_BIT   0
#define RRB_BIT  2 
#define STB1_BIT 5
//C1SR/C1GSR sfr bit defines
#define RBS_BIT  0
#define TBS1_BIT 2
#define TCS1_BIT 3
                  
//C1TFI1/C1RFS sfr bit defines
#define RTR_BIT  30
#define DLC_BITS 16


void Init_CAN1(void)
{
	CFGPIN(PINSEL1, CAN_RX, FUN2); //cfg p0.25 as CAN1_RX pin(RD1)
	C1MOD=1; //Reset CAN1 controller        
	AFMR=2; //all received messages are accepted  
	C1BTR=BTR_LVAL; //Set baud Rate for CAN
	C1MOD=0;					  
}


void CAN1_Tx(struct CAN_Frame txFrame)
{		
	// Checking that the TX buffer is empty
	while(READBIT(C1GSR,TBS1_BIT)==0);//if status is 1 then empty 
	
	C1TID1=txFrame.ID; // place 11-bit tx id in C1T1D1
	
	// place cfg whether data/remote frame & no of data bytes in message
	C1TFI1=(txFrame.BFV.RTR<<RTR_BIT)|(txFrame.BFV.DLC<<DLC_BITS); // Cfg RTR & DLC	
	
	//Check whether Data Frame/Remote Frame to Transmit
	if(txFrame.BFV.RTR!=1)
	{	
		//if data frame,place data into data transmit buffers
		C1TDA1= txFrame.Data1; /*bytes 1-4 */
		C1TDB1= txFrame.Data2; /*bytes 5-8 */
	}
	
	C1CMR|=1<<STB1_BIT|1<<TR_BIT; //Select Tx Buff 1 & Start Xmission
	while(READBIT(C1GSR,TCS1_BIT)==0); //wait until tx complete
}

void CAN1_Rx(struct CAN_Frame *rxFrame)
{
	while(READBIT(C1GSR,RBS_BIT)==0); //wait for CAN frame recv status
	
	rxFrame->ID=C1RID; //read 11-bit CANid of recvd frame.
	
	rxFrame->BFV.RTR=(C1RFS>>RTR_BIT)&1; //& read & extract data/remote frame status
	
	rxFrame->BFV.DLC=(C1RFS>>DLC_BITS)&0x0f; //& extract data length
	
	//check if recvd frame is data frame,
	if(rxFrame->BFV.RTR==0)
	{	
		rxFrame->Data1=C1RDA; //read data bytes 1-4 from C1RDA
		rxFrame->Data2=C1RDB; //read data bytes 5-8 from C1RDB
	}
	
	SETBIT(C1CMR,RRB_BIT); // Release receive buffer command
}          

