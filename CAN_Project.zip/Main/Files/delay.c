#include "types.h"

// Delay functions defination
void delay_us(u32 dlyUS)
{
	dlyUS *= 12; // ~1us @CCLK = 60MHZ
	while(dlyUS--);
}

void delay_ms(u32 dlyMS)
{
	dlyMS *= 12000; // ~1ms @CCLK = 60MHZ
	while(dlyMS--);
}

void delay_s(u32 dlyS)
{
	dlyS *= 12000000; // ~1s @CCLK = 60MHZ
	while(dlyS--);
}
