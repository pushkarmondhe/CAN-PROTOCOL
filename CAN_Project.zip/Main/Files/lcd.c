#include <LPC21xx.h>
#include "defines.h"
#include "types.h"
#include "delay.h"
#include "lcd.h"

//LCD pins connection to port pins
u32 LCD_DATA, LCD_RS, LCD_EN;

void writeLCD(u8 dat)
{
	//write to the data pins any byte;
	WRITEBYTE(IOPIN0,LCD_DATA,dat);
	//make enable pin high
	SSETBIT(IOSET0,LCD_EN);
	delay_us(1);
	//make enable pin low
	SCLRBIT(IOCLR0,LCD_EN);
	//>=1.75 && <=2MS for internal ops
	delay_ms(2);
}

void cmdLCD(u8 cmd)
{
	//select command register for writing to lcd
	SCLRBIT(IOCLR0,LCD_RS);
	//write to command register
	writeLCD(cmd);
}

void charLCD(u8 ch)
{
	//select data register for writing to lcd
	SSETBIT(IOSET0,LCD_RS);
	//write to data register then to DDRAM,CGRAM FOR DISPLAY Build cgram
	writeLCD(ch);
}

void InitLCD(u32 DATA, u32 RS, u32 EN)
{
	LCD_DATA=DATA;
	LCD_RS=RS;
	LCD_EN=EN;
	
	//cfg i/o dir for lcd data,rs,rw,en pins as output pins
	SETBIT(IODIR0,LCD_RS);
	SETBIT(IODIR0,LCD_EN);
	WRITEBYTE(IODIR0,LCD_DATA,255);
	
	delay_ms(40);
	cmdLCD(0x30);
	delay_ms(4);
	delay_us(100);
	cmdLCD(0x30);
	delay_us(100);
	cmdLCD(0x30);
	cmdLCD(MODE_8BIT_2LINE);
	cmdLCD(DSP_ON_CUR_OFF);
	cmdLCD(CLEAR_LCD);
	cmdLCD(SHIFT_DIPS_RIGHT);
}
void strLCD(u8 *ptr)
{
	while(*ptr)
	{
		charLCD(*ptr++);
	}
}


void u32LCD(u32 n)//for unsigned int
{
	u8 a[10];
	s32 i=0;
	do
	{
		a[i]=(n%10)+48;
		i++;
		n/=10;
	} while (n);
	
	for(--i;i>=0;i--)
	{
		charLCD(a[i]);
	}
}

void f32LCD(f32 f,u32 nDP)//float
{
	u32 i,j;
	if(f<0.0)
	{
		charLCD('-');
		f=-f;
	}
	i=f;
	u32LCD(i);
	charLCD('.');
	for(j=0;j<nDP;j++)
	{
		f=(f-i)*10;
		i=f;
		charLCD(i+48);
	}
}
