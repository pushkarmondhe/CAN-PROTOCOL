#include <LPC21xx.h>
#include <math.h>
#include "can.h"
#include "types.h"
#include "defines.h"

#define LED_AL 0

int main()
{
	u32 bin=0;
	struct CAN_Frame rxFrame;
	
	Init_CAN1();
	WRITEBYTE(IODIR0, LED_AL, 0xFF); // Set as output
	WRITEBYTE(IOPIN0, LED_AL, 0xFF); // Initially turn off

	while(1)
	{
		CAN1_Rx(&rxFrame);
		if(rxFrame.ID==1)
		{
			bin = pow(2, ((rxFrame.Data1*8)/100))-1;
			WRITEBYTE(IOPIN0, LED_AL, ~bin); // Display in the form of led_al
		}
	}
}
